
             <form name="mpsForm" action="includes/disburse.php" method="post" class="booking-form">			
					<div class="tm-form-inner">							
					    <div class="form-group" style="color:#000;">
                            <label>ID number</label>
                            <input type="text" class="form-control" name="id" placeholder="Applicant's ID number">
                        </div>				
				        <div class="form-group" style="color:#000;">
                            <label>Amount awarded</label>
                            <input type="number" class="form-control" name="amount" placeholder="Amount disbursed">
                        </div>             
				        <div class="form-group tm-yellow-gradient-bg text-center">
						    <button type="submit" name="submit" value="send" class="button btn largesearch-btn">Submit</button>						            							            	
				        </div>
				        <div class="form-group tm-yellow-gradient-bg text-center">
						    <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#4a763c; color:#fff;">Reset</button>						            							            	
				        </div>
                    </div>
			   </form>