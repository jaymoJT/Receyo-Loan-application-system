<?php include 'head.php';?>
<?php include 'topbar.php';?>
<?php include 'menu.php';?>

<?php 
$sql = 'SELECT id, name, phone, FROM applications';

mysql_select_db('receyo');
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not get data: ' . mysql_error());
}
while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
    echo "id :{$row['id']}  <br> ".
         "name : {$row['name']} <br> ".
         "phone : {$row['phone']} <br> ".
         "--------------------------------<br>";
} 
echo "Fetched data successfully\n";
mysql_close($conn);

 ?>