<div class="footer-area fixed-bottom">
        
            <div class="footer-copy text-center">
                <div class="container">
                    <div class="row">
                        <div class="pull-left">
                            <span> Developed by <a href="https://www.facebook.com/jimmytechies/">Jitnet softwares</a>  2018  </span>  
                        </div> 
                    </div>
                </div>
            </div>           
</div>