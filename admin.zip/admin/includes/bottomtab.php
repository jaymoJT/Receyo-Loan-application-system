        <nav class="navbar navbar-default ">
            <div class="container">
                <?php include 'search.php';?>
               
            </div><!-- /.container-fluid -->
        </nav>
        <!-- End of nav bar -->