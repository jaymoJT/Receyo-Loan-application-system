<?php 

   $servername = "localhost";
   $username   = "root";
   $password   = "";
   $dbname     = "receyo";

   //creating connection
   $conn = mysqli_connect ($servername, $username, $password, $dbname);

   //confirming connection
   if (!$conn) 
   {
   	"Connection failed:" . mysqli_connect_error();
   }


?>
