<?php
 if (isset($_POST['submit']))
 {   include 'connect.php';

    $name        = mysqli_real_escape_string($conn,$_POST['name']); 
    $password = mysqli_real_escape_string($conn,$_POST['password']);

    
    //Error handlers
    //Check for empty fields..
    if (empty($name)|| 
        empty($password)
        ) 
    {
        echo "The fields are empty";
        exit();
    }

    else {
        echo "  <script type=text/javascript >
                 alert('Teller registered successfully');
                   location.href='../add_teller.php?server=teller registered successfully';
                </script> ";
    }
   
  }  

   $hashedPwd = password_hash($password, PASSWORD_DEFAULT);
   $sql = "INSERT INTO tellers (name,password)
                VALUES ('$name','$password')";

    if (mysqli_query($conn, $sql))
     {
        echo "Teller added successfully. ";
    }

    else 
        {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

    
     mysqli_close($conn);

?>    