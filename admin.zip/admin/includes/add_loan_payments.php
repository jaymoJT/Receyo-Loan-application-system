<?php
 if (isset($_POST['submit']))
 {   include 'connect.php';

    $id        = mysqli_real_escape_string($conn,$_POST['id']); 
    $amount = mysqli_real_escape_string($conn,$_POST['amount']);
    $date = mysqli_real_escape_string($conn,$_POST['date']);

    
    //Error handlers
    //Check for empty fields..
    if (empty($id)|| 
        empty($amount) ||
        empty($date)
        ) 
    {
         echo "  <script type=text/javascript >
                 alert('Fields are empty');
                   location.href='../add_loan_payments.php?server=Empty fields!';
                </script> ";
    }

    else {
        echo "  <script type=text/javascript >
                 alert('Loan paid successfully');
                   location.href='../add_loan_payments.php?server=Loan paid successfully!';
                </script> ";
    }
   
  }  

   
   $sql = "INSERT INTO loan_payments (id,amount,pay_date)
                VALUES ('$id','$amount','$date')";

    if (mysqli_query($conn, $sql))
     {
        echo "Loan disbursed successfully. ";
    }

    else 
        {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

    
     mysqli_close($conn);

?>    
<?php

if(isset($_POST['send'])) {
   // Prepare the email
$to = "pridedrivetours@gmail.com";

$name = $_POST['name'];
$mail_from = $_POST["email"];
$subject = 'Message sent from Pride drive tours';
$message = $_POST['message'];

 $header = "From:$name <$mail_from>";

   // Send it
   $sent = mail($to, $subject, $message, $header );
   if($sent) {
   echo 'Your message has been sent successfully!';
   } else {
   echo 'Sorry, your message could not send.';
   }
}
?>