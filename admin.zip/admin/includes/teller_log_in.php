<?php
  session_start();

if (isset($_POST['submit']))
  {
	include_once 'connect.php';

	$name = mysqli_real_escape_string($conn,$_POST['name']);
	$password = mysqli_real_escape_string($conn,$_POST['password']);

	//Error handlers
	//checking for empty fields
	if (empty($name) || empty($password) ) {
		header("Location:../index.php?login=Empty");
		exit();
	} else{

		$sql = "SELECT * FROM tellers WHERE name = '$name'";
		$result = mysqli_query($conn,$sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck < 1) {
			header("Location: ../index.php?login=InvalidUsername");
			exit();
		} else {
			if (password_verify($ppassword, $row['password'])) 
			    {
	             //Login the user here
	                $_SESSION['teller_id'] = $row['teller_id'];
	                $_SESSION['name'] = $row['name'];
	                $_SESSION['password'] = $row['password'];
	                    header("Location: ../registration.php?login=success");
	                    exit();
                } else 
                {
	                header("Location: ../index.php?login=error");
	                exit();
                }
            }
		}
	}
?>    