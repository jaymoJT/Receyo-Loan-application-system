<?php
 if (isset($_POST['submit']))
 {   include 'connect.php';

    $id        = mysqli_real_escape_string($conn,$_POST['id']); 
    $amount = mysqli_real_escape_string($conn,$_POST['amount']);

    
    //Error handlers
    //Check for empty fields..
    if (empty($id)|| 
        empty($amount)
        ) 
    {
        echo "The fields are empty";
        exit();
    }

    else {
        echo "  <script type=text/javascript >
                 alert('The client has been awarded successfully');
                   location.href='../index.php?server=Loan disbursed successfully!';
                </script> ";
    }
   
  }  

   $hashedPwd = password_hash($password, PASSWORD_DEFAULT);
   $sql = "INSERT INTO disbursed (id,amount)
                VALUES ('$id','$amount')";

    if (mysqli_query($conn, $sql))
     {
        echo "Loan disbursed successfully. ";
    }

    else 
        {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

    
     mysqli_close($conn);

?>    
<?php

if(isset($_POST['submit'])) {
   // Prepare the email
$to = "ariembijames@gmail.com";

$id = $_POST["id"];
$subject = 'Message sent from Pride drive tours';
$amount = $_POST['amount'];

 $header = "From:Receyo_system <$id>";

   // Send it
   $sent = mail($to, $subject, $amount, $header );
   if($sent) {
   echo 'Your message has been sent successfully!';
   } else {
   echo 'Sorry, your message could not send.';
   }
}
?>