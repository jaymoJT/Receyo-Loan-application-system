<?php include 'includes/head.php'; ?>
<?php include 'includes/connect.php';?>

<?php 

$sql = "SELECT id, name, phone, estate, mode, amount  FROM applications";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>phone</th>
                <th>estate</th>
                <th>mode</th>
                <th>amount</th>
            </tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo    "<tr><td>".
                    $row["id"].
                "</td><td>".
                    $row["name"].
                "</td><td>".
                    $row["phone"].
                "</td><td>".
                    $row["estate"].
                "</td><td>".
                    $row["mode"].
                "</td><td>".
                    $row["amount"].                                    
                "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();

;?>

                                      
    
