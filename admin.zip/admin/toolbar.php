<nav class="navbar navbar-default ">
            <div class="container">
                <a href="add_teller.php">
                    <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#17159a; color:#fff;">Add teller</button>
                </a>
                <a href="index.php">
                   <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#17159a; color:#fff;">Disburse a loan</button>   
                </a>
                <a href="add_loan_payments.php">
                   <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#17159a; color:#fff;">Submit payments</button>   
                </a>
                <a href="#">
                    <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#17159a; color:#fff;">
                   Reports
                </button>
                </a>
                <a href="#">
                   <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#17159a; color:#fff;">Finance/Accounts</button>   
                </a>
                
                
                
                
                
                
                
            </div><!-- /.container-fluid -->
        </nav>