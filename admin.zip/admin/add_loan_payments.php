<?php 
include 'includes/head.php';
include 'includes/topbar.php';
include 'includes/menu.php';
include 'toolbar.php';
?>


<div class="content-area single-property" style="background-color: #FCFCFC;">&nbsp;
            <div class="container">   
                <div class="clearfix padding-top-40" >
                    <div class="col-md-6 single-property-content prp-style-1 ">
                        
                        <div class="single-property-wrapper">
                        <div class="single-property-header">
                            <h1 class="property-title pull-left">Submit loan payments</h1>
                        </div>    
                <form name="mpsForm" action="includes/add_loan_payments.php" method="post" class="booking-form">         
                        <div class="tm-form-inner">                         
                        <div class="form-group" style="color:#000;">
                            <label>ID number</label>
                            <input type="text" class="form-control" name="id" placeholder="Applicant's ID number">
                        </div>              
                        <div class="form-group" style="color:#000;">
                            <label>Amount awarded</label>
                            <input type="number" class="form-control" name="amount" placeholder="Amount disbursed">
                        </div>  
                        <div class="form-group" style="color:#000;">
                            <label>Date</label>
                                <div class='input-group date' id='datetimepicker2'>
                                    <input name="date" type="date">
                                </div>
                        </div>          
                        <div class="form-group tm-yellow-gradient-bg text-center">
                            <button type="submit" name="submit" value="send" class="button btn largesearch-btn">Submit</button>                                                                             
                        </div>
                        <div class="form-group tm-yellow-gradient-bg text-center">
                            <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#4a763c; color:#fff;">Reset</button>                                                                             
                        </div>
                    </div>
               </form>
                        </div>
                    </div>
                    <div class="col-md-4 p0">                        
                        
                        <?php 
                         
                         echo "Welcome to Rise Eastern Congo Entrepreneural Youths";

                        ?>
                        
                    </div>                                                           
                    </div>
                </div>
            </div>
        </div>

<?php 
include 'includes/bottomtab.php';
include 'includes/footer.php';

?>