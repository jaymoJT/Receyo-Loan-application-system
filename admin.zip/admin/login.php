<?php include 'includes/head.php';?>

<div class="content-area single-property" style="background-color: #FCFCFC;">&nbsp;
            <div class="container">   
                <div class="clearfix padding-top-40" >
                    <div class="col-md-6 single-property-content prp-style-1 ">
                        <div class="row">
                            <div class="light-slide-item">            
                                <div class="clearfix">
                                    <div class="favorite-and-print">
                                        <a class="add-to-fav" href="#login-modal" data-toggle="modal">
                                            <i class="fa fa-star-o"></i>
                                        </a>
                                        <a class="printer-icon " href="javascript:window.print()">
                                            <i class="fa fa-print"></i> 
                                        </a>
                                    </div>                                    
                                </div>
                            </div>
                        </div>
                        <div class="single-property-wrapper">    
                            <form name="mpsForm" action="includes/teller_log_in.php" method="post" class="booking-form">            
                                <div class="tm-form-inner">                         
                                    <div class="form-group" style="color:#000;">
                                        <label>Username name</label>
                                        <input type="text" class="form-control" name="name" placeholder="Your name">
                                    </div>              
                                    <div class="form-group" style="color:#000;">
                                        <label>Password</label>
                                        <input type="password" class="form-control" name="password" placeholder="Your password">
                                    </div>             
                                    <div class="form-group tm-yellow-gradient-bg text-center">
                                        <button type="submit" name="submit" value="send" class="button btn largesearch-btn">Submit</button>                                                                             
                                    </div>
                                    <div class="form-group tm-yellow-gradient-bg text-center">
                                        <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#4a763c; color:#fff;">Reset</button>                                                                             
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-4 p0">                        
                        
                        <?php 
                         
                         echo "Welcome to Rise Eastern Congo Entrepreneural Youths";

                        ?>
                        
                    </div>                                                           
                </div>
            </div>
</div>
       

<?php include 'includes/footer.php';?>