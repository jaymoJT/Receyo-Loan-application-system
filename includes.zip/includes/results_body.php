<!-- property area -->
        <div class="content-area single-property" style="background-color: #FCFCFC;">&nbsp;
            <div class="container">   

                <div class="clearfix padding-top-40" >

                    <div class="col-md-8 single-property-content prp-style-1 ">
                        <div class="row">
                            <div class="light-slide-item">            
                                <div class="clearfix">
                                    <div class="favorite-and-print">
                                        <a class="add-to-fav" href="#login-modal" data-toggle="modal">
                                            <i class="fa fa-star-o"></i>
                                        </a>
                                        <a class="printer-icon " href="javascript:window.print()">
                                            <i class="fa fa-print"></i> 
                                        </a>
                                    </div>                                    
                                </div>
                            </div>
                        </div>
                        <div class="single-property-wrapper">    
                            <?php include 'search.php'; ?>
                        </div>
                    </div>


                    <div class="col-md-4 p0">
                        <?php include 'search_form.php' ;?>
                    </div>             
                                              
                    </div>
                </div>

            </div>
        </div>