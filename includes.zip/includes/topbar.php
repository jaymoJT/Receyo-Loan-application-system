<div class="header-connect">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-8  col-xs-12">
                        <div class="header-half header-call">

                            <p>
                                <span style="color:#4a763c;"><i class="pe-7s-call"></i> +254 (0) 728429931</span>
                                <span style="color:#4a763c;"><i class="pe-7s-mail"></i> info@receyo.org</span>
                            </p>
                        </div>
                    </div>                    
                </div>
            </div>                
</div>   