<?php



 if (isset($_POST['submit']))
 {   include 'connect.php';

    $id        = mysqli_real_escape_string($conn,$_POST['id']); 
    $applicant = mysqli_real_escape_string($conn,$_POST['applicant']);
    $email     = mysqli_real_escape_string($conn,$_POST['email']);
    $phone     = mysqli_real_escape_string($conn,$_POST['phone']);
    $estate    = mysqli_real_escape_string($conn,$_POST['estate']);
    $date      = mysqli_real_escape_string($conn,$_POST['date']); 
    $mode      = mysqli_real_escape_string($conn,$_POST['mode']);
    $amount    = mysqli_real_escape_string($conn,$_POST['amount']);
    
    //Error handlers
    //Check for empty fields..
    if (empty($id)|| 
        empty($applicant) ||
        empty($email)|| 
        empty($phone)|| 
        empty($estate)|| 
        empty($date)|| 
        empty($mode)|| 
        empty($amount)
        ) 
    {
         echo
        "<script type=text/javascript>
            alert('Some fields are empty');
            location.href='../index.php';
        </script>";
    }

    else {
        echo
        "<script type=text/javascript>
            alert('Application submited successfully');
            location.href='../index.php';
        </script>";
        
    }   
   
  }  

$sql = "INSERT INTO applications (id,name,email,phone,estate,app_date,mode,amount)
VALUES ('$id','$applicant','$email','$phone','$estate','$date','$mode','$amount')";

    if (mysqli_query($conn, $sql))
     {
        echo "Application sent successfully. ";
    }

    else 
        {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

    
     mysqli_close($conn);

?>    