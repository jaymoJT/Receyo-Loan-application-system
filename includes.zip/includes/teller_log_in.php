<?php
include_once 'connect.php';
  session_start();


if (isset($_POST['submit']))
  {
	

	$name = mysqli_real_escape_string($conn,$_POST['name']);
	$password = mysqli_real_escape_string($conn,$_POST['password']);

	//Error handlers
	//checking for empty fields
	if (empty($name) || empty($password) ) {
		echo
		"<script type=text/javascript>
			alert('Please input your Username/Password!');
			location.href='../login.php';
		</script>";
		
	}	
		

	 else{

		$sql = "SELECT * FROM tellers WHERE name = '$name'";
		$result = mysqli_query($conn,$sql);
		$resultCheck = mysqli_fetch_array($result,MYSQLI_ASSOC);
		//var_dump($resultCheck);
			//die("Works");
		if (!$resultCheck) {

			header("Location: ../login.php?login=error");
			
		} else {
			if ($password == $password1) 
			    {
	             //Login the user here
			    	
	                $_SESSION['teller_id'] = $row['teller_id'];
	                $_SESSION['name'] = $row['name'];
	                $_SESSION['password'] = $row['password'];
	                    header("Location: ../index.php?login=success");
	                    exit();
                } else 
                {
	            echo "OK";
                }
            }
		}
	}
?>    