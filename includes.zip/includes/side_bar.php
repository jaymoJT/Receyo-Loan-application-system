<aside class="sidebar sidebar-property blog-asside-right">
    <?php include 'search_form.php' ;?> <br>
    <?php include 'application_date.php'; ?>
</aside>