        <nav class="navbar navbar-default ">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse yamm" id="navigation">
                    
                    <ul class="main-nav nav navbar-nav navbar-right">
                        <li class="dropdown ymm-sw " data-wow-delay="0.1s">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="200" style="color:#000;" ><i class="fas fa-users" ></i> Clients <b class="caret"></b></a>
                            <ul class="dropdown-menu navbar-nav">
                                <li class="wow fadeInDown" data-wow-delay="0.4s"><a href="awarded.php?monthly=All awarded loan applicants" style="color:#000;" >All</a></li>
                                <li class="wow fadeInDown" data-wow-delay="0.1s"><a class="" href="today.php?today=Clients who applied for loans today" style="color:#000;">Today's applicants</a></li>
                                <li class="wow fadeInDown" data-wow-delay="0.4s"><a href="weekly.php?weekly=clients paying their loans weekly" style="color:#000;">Weekly payers</a></li>
                                <li class="wow fadeInDown" data-wow-delay="0.4s"><a href="monthly.php?monthly=clients paying their loans monthly" style="color:#000;">Monthly payers</a></li>
                            </ul>
                        </li>
                        <li class="wow fadeInDown" data-wow-delay="0.1s"><a class="" href="index.php" style="color:#000;"><i class="fas fa-chalkboard-teacher"></i> Application form</a></li>
                        <li class="wow fadeInDown" data-wow-delay="0.1s"><a class="" href="applicants.php?Applicants=All loan applicants" style="color:#000;"><i class="fas fa-user-alt"></i> All Applicants</a></li>
                        <li class="dropdown ymm-sw " data-wow-delay="0.1s">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="200" style="color:#000;"><i class="fas fa-user-lock"></i> Users <b class="caret"></b></a>
                            <ul class="dropdown-menu navbar-nav">
                                <li class="wow fadeInDown" data-wow-delay="0.4s"><a href="index.php?monthly=All awarded loan applicants" style="color:#000;" >Teller</a></li>
                                <li class="wow fadeInDown" data-wow-delay="0.1s"><a class="" href="#" style="color:#000;">Accounts/finance</a></li>
                                <li class="wow fadeInDown" data-wow-delay="0.4s"><a href="admin/index.php" style="color:#000;">Admin</a></li>
                            </ul>
                        </li>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
        <!-- End of nav bar -->